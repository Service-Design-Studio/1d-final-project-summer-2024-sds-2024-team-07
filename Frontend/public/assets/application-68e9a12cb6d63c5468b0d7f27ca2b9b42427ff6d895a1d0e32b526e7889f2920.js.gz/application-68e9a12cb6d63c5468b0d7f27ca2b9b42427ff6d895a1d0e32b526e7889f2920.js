// app/javascript/application.js

import "@hotwired/turbo-rails"
import "controllers"

import "bootstrap"
import "@popperjs/core";
